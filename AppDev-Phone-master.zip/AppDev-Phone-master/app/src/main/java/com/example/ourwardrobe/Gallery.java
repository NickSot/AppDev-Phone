package com.example.ourwardrobe;

import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.ourwardrobe.databinding.ActivityGalleryBinding;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class Gallery extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityGalleryBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_gallery);



        Button image = findViewById(R.id.pickimage);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ActivityCompat.checkSelfPermission(Gallery.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(Gallery.this, new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
                    return;


                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                //Allow multiple images
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setType("image/*");
                startActivityForResult(intent, 1);

            }
        });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK){
            ImageView img = findViewById(R.id.image_view);
            List<Bitmap> bitmap = new ArrayList<>();
            ClipData clipData = data.getClipData();
            if(clipData!= null){

                for(int i =0; i<clipData.getItemCount(); i++){
                    Uri imageUri = clipData.getItemAt(i).getUri();
                    //InputStream is = getContentResolver().openInputStream(imageUri);
                    try {
                        InputStream is = getContentResolver().openInputStream(imageUri);
                        Bitmap bitmap1 = BitmapFactory.decodeStream(is);
                        bitmap.add(bitmap1);
                    }
                    catch (FileNotFoundException e){
                        e.printStackTrace();
                    }
                }
            }else{
                Uri imageUri = data.getData();
                try{
                    InputStream is = getContentResolver().openInputStream(imageUri);
                    Bitmap bitmap1 = BitmapFactory.decodeStream(is);
                    bitmap.add(bitmap1);
                }
                catch (FileNotFoundException e){
                    e.printStackTrace();
                }
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (Bitmap b:bitmap) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                img.setImageBitmap(b);
                            }
                        });
                        try{
                            Thread.sleep(3000);
                        }
                        catch (InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                }
            }).start();


        }
    }
}