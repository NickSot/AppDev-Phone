package com.example.ourwardrobe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class shirts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shirts);
    }
}